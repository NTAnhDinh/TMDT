package com.tmdt.config;

public enum  PaypalPaymentIntent {
    sale
}
